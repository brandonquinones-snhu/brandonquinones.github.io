package com.example.cs360_bquinones

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity

class SmsNotificationActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sms_notifications)

        // Initialize UI elements
        val phoneNumberEditText = findViewById<EditText>(R.id.editTextPhonetic)
        val emailEditText = findViewById<EditText>(R.id.editTextEmail)
        val submitButton = findViewById<Button>(R.id.submitButton)

        // Handle Submit button click
        submitButton.setOnClickListener {
            val phoneNumber = phoneNumberEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()

            if (phoneNumber.isNotEmpty() && email.isNotEmpty() && isValidPhoneNumber(phoneNumber) && isValidEmail(email)) {
                Toast.makeText(this, "Details submitted:\nPhone: $phoneNumber\nEmail: $email", Toast.LENGTH_SHORT).show()
            } else if (phoneNumber.isNotEmpty() && isValidPhoneNumber(phoneNumber)) {
                Toast.makeText(this, "Phone number submitted: $phoneNumber", Toast.LENGTH_SHORT).show()
            } else if (email.isNotEmpty() && isValidEmail(email)) {
                Toast.makeText(this, "Email submitted: $email", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Invalid phone number or email. Please try again.", Toast.LENGTH_SHORT).show()
            }
        }

        // Intent to change pages
        val summaryButton = findViewById<Button>(R.id.goToSummary)
        val calendarButton = findViewById<Button>(R.id.goToCalendar)

        summaryButton.setOnClickListener {
            startActivity(Intent(this, SummaryActivity::class.java))
        }
        calendarButton.setOnClickListener {
            startActivity(Intent(this, CalendarActivity::class.java))
        }
    }

    // Function to validate phone number
    private fun isValidPhoneNumber(phoneNumber: String): Boolean {
        return phoneNumber.matches("^\\+?[0-9]{10,15}$".toRegex())
    }

    // Function to validate email
    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
}
