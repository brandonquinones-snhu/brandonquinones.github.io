export class User {
    email: string;
    name: string;
    userRole: string; // 👈 Added userRole to the User class

    constructor() {
        this.email = '';
        this.name = '';
        this.userRole = 'traveler'; // 👈 Default role is 'traveler'
    }
}
