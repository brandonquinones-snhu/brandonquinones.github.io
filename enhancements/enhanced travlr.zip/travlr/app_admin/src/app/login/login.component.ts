import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { User } from '../models/user';
import { jwtDecode } from 'jwt-decode';

interface JwtPayload {
  _id: string;
  email: string;
  name: string;
  userRole: 'admin' | 'traveler';
  exp: number;
}

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  public formError: string = '';
  public isForbidden: boolean = false; // 👈 added this to track unauthorized access
  submitted = false;

  credentials = {
    name: '',
    email: '',
    password: ''
  }

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService
  ) { }

  ngOnInit(): void {}

  public onLoginSubmit(): void {
    this.formError = '';
    if (!this.credentials.email || !this.credentials.password || !this.credentials.name) {
      this.formError = 'All fields are required, please try again';
      this.router.navigateByUrl('#');
    } else {
      this.doLogin();
    }
  }

  private doLogin(): void {
    const newUser = {
      name: this.credentials.name,
      email: this.credentials.email
    } as User;

    this.authenticationService.login(newUser, this.credentials.password)
      .subscribe({
        next: (res: any) => {
          const token = res.token;
          localStorage.setItem('token', token);

          const decoded: JwtPayload = jwtDecode(token);
          const role = decoded.userRole;

          if (role === 'admin') {
            this.router.navigate(['/']);
          } else {
            this.isForbidden = true; // 👈 added this to show forbidden message on screen
          }
        },
        error: (err) => {
          console.error('Login error:', err);
          // Check if the error is a 403 Forbidden
          if (err.status === 403) {
            this.formError = 'You are not authorized to log into this resource.';
          } else {
            this.formError = 'Invalid credentials or server error.';
          }
        }
      });
  }
}
