package appointment;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AppointmentService {

    // Private list for storing appointments
    private final List<Appointment> appointmentList = new ArrayList<>();

	// Adding a new appointment with passed attributes
	public void addAppointment(String firstName, String lastName, int age, String gender, String email, 
							String phoneNumber, boolean isNewPatient, String preferredPhysician, 
							LocalDateTime appointmentDate, String reasonForVisit) {
	
		// Create the Appointment object
		Appointment newAppointment = new Appointment(firstName, lastName, age, gender, 
			email, phoneNumber, isNewPatient, preferredPhysician, appointmentDate, reasonForVisit);

		// Add the newly created appointment to the list
		appointmentList.add(newAppointment);
	}


	// Deleting appointment based on appointmentID (safe iteration)
    public void deleteAppointment(String appointmentID) {
        Iterator<Appointment> iterator = appointmentList.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getAppointmentID().toString().equals(appointmentID)) {
                iterator.remove(); // Safe removal
                return; // Stop after deleting the first match
            }
        }
    }

    // Getter for appointment list (optional)
    public List<Appointment> getAppointmentList() {
        return new ArrayList<>(appointmentList); // Return a copy to avoid external modifications
    }
}
