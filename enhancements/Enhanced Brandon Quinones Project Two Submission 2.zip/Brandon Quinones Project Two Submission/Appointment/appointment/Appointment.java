package appointment;

import java.time.LocalDateTime;
import java.util.UUID;

public class Appointment {

    private UUID appointmentID; // Unique appointment ID
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String email;
    private String phoneNumber; // Nullable
    private boolean isNewPatient;
    private String preferredPhysician; // Nullable
    private LocalDateTime appointmentDate;
	private String reasonForVisit;
    private long patientID; // 64-bit unique patient ID

    // Constructor
    public Appointment(String firstName, String lastName, int age, String gender, String email, String phoneNumber,
                       boolean isNewPatient, String preferredPhysician, LocalDateTime appointmentDate, String reasonForVisit) {

        this.appointmentID = UUID.randomUUID(); // Generate unique UUID
        this.firstName = validateName(firstName);
        this.lastName = validateName(lastName);
        this.age = validateAge(age);
        this.gender = validateGender(gender);
        this.email = validateEmail(email);
        this.phoneNumber = phoneNumber; // Can be null
        this.isNewPatient = isNewPatient;
        this.preferredPhysician = preferredPhysician; // Can be null
        this.appointmentDate = validateDate(appointmentDate);
        this.reasonForVisit = validateReasonForVisit(reasonForVisit);
		this.patientID = getPatientID(); // Generate a 64-bit patient ID
	}

    // Generate a random 64-bit patient ID
    private long generatePatientID() {
        return (long) (Math.random() * Long.MAX_VALUE);
    }

    // Validate name (not null or blank)
    private String validateName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name cannot be null or blank.");
        }
        return name;
    }

    // Validate age (must be positive)
    private int validateAge(int age) {
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be a positive number.");
        }
        return age;
    }

    // Validate gender (optional, but enforce standard values)
    private String validateGender(String gender) {
        if (gender == null || gender.isBlank()) {
            throw new IllegalArgumentException("Gender cannot be null or blank.");
        }
        return gender;
    }

    // Validate email (must not be null or blank)
    private String validateEmail(String email) {
        if (email == null || email.isBlank() || !email.contains("@")) {
            throw new IllegalArgumentException("Email is required and must be a valid email address.");
        }
        return email;
    }

    // Validate date is in the future
    private LocalDateTime validateDate(LocalDateTime appointmentDate) {
        if (appointmentDate == null || appointmentDate.isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Appointment date must be in the future.");
        }
        return appointmentDate;
    }

// Validate reasonForVisit length
private String validateReasonForVisit(String reasonForVisit) {
    if (reasonForVisit == null || reasonForVisit.length() < 1 || reasonForVisit.length() > 50) {
        throw new IllegalArgumentException("Reason for visit must be between 1 and 50 characters.");
    }
    return reasonForVisit;
}


    // Getters
    public UUID getAppointmentID() {
        return appointmentID;
    }

	public long getPatientID() {
		if (this.patientID == 0) { // If patientID is not assigned yet, generate one 
			// this is dummy logic hence the (== 0) but ideally a database check would 
			// be done against something like a social security number...
			this.patientID = generatePatientID();
		}
		return this.patientID;
	}
	

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public boolean isNewPatient() {
        return isNewPatient;
    }

	public String getPreferredPhysician() {
        return preferredPhysician;
    }

    public LocalDateTime getAppointmentDate() {
        return appointmentDate;
    }

    public String getReasonForVisit() {
        return reasonForVisit;
    }
}