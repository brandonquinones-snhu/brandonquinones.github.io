package test;

import static org.junit.Assert.*;

import java.time.LocalDateTime;
import java.util.UUID;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import appointment.Appointment;

public class AppointmentTest {

    private Appointment testAppointment;
    private LocalDateTime testAppointmentDate;
    private String testReasonForVisit;
    private String testFirstName;
    private String testLastName;
    private int testAge;
    private String testGender;
    private String testEmail;
    private String testPhoneNumber;
    private boolean testIsNewPatient;
    private String testPreferredPhysician;

    @Before
    public void setUp() {
        // Setup test values for new fields
        testAppointmentDate = LocalDateTime.now().plusDays(1); // Future date
        testReasonForVisit = "This is a test appointment."; 
        testFirstName = "John";
        testLastName = "Doe";
        testAge = 30;
        testGender = "Male";
        testEmail = "john.doe@example.com";
        testPhoneNumber = "123-456-7890";
        testIsNewPatient = true;
        testPreferredPhysician = "Dr. Smith";

        // Create an Appointment instance for testing with new fields
        testAppointment = new Appointment(testFirstName, testLastName, testAge, testGender, testEmail, testPhoneNumber,
			testIsNewPatient, testPreferredPhysician, testAppointmentDate, testReasonForVisit);
    }

    @After
    public void tearDown() {
        testAppointment = null; // Cleanup after each test
    }

    @Test
    public void testAppointmentConstructor() {
        assertNotNull("Appointment object should not be null", testAppointment);
        assertFalse("Appointment ID should not be empty", testAppointment.getAppointmentID().toString().isEmpty());
        assertEquals("Appointment date should match", testAppointmentDate, testAppointment.getAppointmentDate());
        assertEquals("Reason for visit should match", testReasonForVisit, testAppointment.getReasonForVisit()); // Updated field
        assertEquals("First name should match", testFirstName, testAppointment.getFirstName());
        assertEquals("Last name should match", testLastName, testAppointment.getLastName());
        assertEquals("Age should match", testAge, testAppointment.getAge());
        assertEquals("Gender should match", testGender, testAppointment.getGender());
        assertEquals("Email should match", testEmail, testAppointment.getEmail());
        assertEquals("Phone number should match", testPhoneNumber, testAppointment.getPhoneNumber());
        assertEquals("New patient status should match", testIsNewPatient, testAppointment.isNewPatient());
        assertEquals("Preferred physician should match", testPreferredPhysician, testAppointment.getPreferredPhysician());
        assertFalse("Patient ID not be zero", testAppointment.getPatientID() == 0);
    }

    @Test
    public void testGetAppointmentID() {
        assertFalse("Appointment ID should not be empty", testAppointment.getAppointmentID().toString().isEmpty());
    }

    @Test
    public void testGetAppointmentDate() {
        assertEquals("Appointment date should be correct", testAppointmentDate, testAppointment.getAppointmentDate());
    }

    @Test
    public void testGetReasonForVisit() {
        assertEquals("Reason for visit should be correct", testReasonForVisit, testAppointment.getReasonForVisit()); // Updated field
    }

    @Test
    public void testGetFirstName() {
        assertEquals("First name should be correct", testFirstName, testAppointment.getFirstName());
    }

    @Test
    public void testGetLastName() {
        assertEquals("Last name should be correct", testLastName, testAppointment.getLastName());
    }

    @Test
    public void testGetAge() {
        assertEquals("Age should be correct", testAge, testAppointment.getAge());
    }

    @Test
    public void testGetGender() {
        assertEquals("Gender should be correct", testGender, testAppointment.getGender());
    }

    @Test
    public void testGetEmail() {
        assertEquals("Email should be correct", testEmail, testAppointment.getEmail());
    }

    @Test
    public void testGetPhoneNumber() {
        assertEquals("Phone number should be correct", testPhoneNumber, testAppointment.getPhoneNumber());
    }

    @Test
    public void testIsNewPatient() {
        assertEquals("New patient status should be correct", testIsNewPatient, testAppointment.isNewPatient());
    }

    @Test
    public void testGetPreferredPhysician() {
        assertEquals("Preferred physician should be correct", testPreferredPhysician, testAppointment.getPreferredPhysician());
    }

    @Test
    public void testGetPatientID() {
        assertFalse("Patient ID not be zero", testAppointment.getPatientID() == 0);
    }
}
