package test;

import static org.junit.Assert.*;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;

import appointment.Appointment;
import appointment.AppointmentService;

public class AppointmentServiceTest {

    private AppointmentService testAppointmentService;

    @Before
    public void setUp() {
        // Initialize the AppointmentService before each test
        testAppointmentService = new AppointmentService();

        // Initialize the elements separately
        String firstName = "John";
        String lastName = "Doe";
        int age = 30;
        String gender = "Male";
        String email = "john.doe@example.com";
        String phoneNumber = "123-456-7890";
        boolean isNewPatient = true;
        String preferredPhysician = "Dr. Smith";
        LocalDateTime firstAppointmentDate = LocalDateTime.now().plusDays(1); // Tomorrow
        String firstReasonForVisit = "This is the first appointment!";

        // Create a sample appointment using the initialized elements
        testAppointmentService.addAppointment(firstName, lastName, age, gender, email, phoneNumber, 
                                              isNewPatient, preferredPhysician, firstAppointmentDate, firstReasonForVisit);
    }

    @Test
    public void testAddAppointment() {
        // Initialize the elements for the new appointment
        String firstName = "Jane";
        String lastName = "Doe";
        int age = 28;
        String gender = "Female";
        String email = "jane.doe@example.com";
        String phoneNumber = "987-654-3210";
        boolean isNewPatient = false;
        String preferredPhysician = "Dr. Johnson";
        LocalDateTime newAppointmentDate = LocalDateTime.now().plusDays(3);
        String newReasonForVisit = "This is a test for AppointmentService class!";

        // Add the new appointment using the initialized elements
        testAppointmentService.addAppointment(firstName, lastName, age, gender, email, phoneNumber, 
                                              isNewPatient, preferredPhysician, newAppointmentDate, newReasonForVisit);

        // Verify the appointment was added correctly
        boolean found = false;
        for (Appointment appointment : testAppointmentService.getAppointmentList()) {
        // Check if the UUID matches
        if (!appointment.getAppointmentID().toString().isEmpty()) {
            // Assert the lastName
            assertEquals(lastName, appointment.getLastName());
            found = true;
			System.out.println(appointment.getPatientID());
        	}
        }
        assertTrue("The new appointment should be found in the list", found);
    }

    @Test
    public void testDeleteAppointment() {
        // Get the first appointment ID as a String
        String deleteAppointmentID = testAppointmentService.getAppointmentList().get(0).getAppointmentID().toString();

        // Delete the appointment
        testAppointmentService.deleteAppointment(deleteAppointmentID);

        // Ensure it's no longer in the list
        for (Appointment appointment : testAppointmentService.getAppointmentList()) {
            assertNotEquals("Deleted appointment should not be in the list", deleteAppointmentID, appointment.getAppointmentID().toString());
        }
    }
}
