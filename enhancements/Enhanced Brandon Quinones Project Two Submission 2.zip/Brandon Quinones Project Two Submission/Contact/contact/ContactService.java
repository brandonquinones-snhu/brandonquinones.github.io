package contact;
import java.util.ArrayList;
import java.util.List;

public class ContactService {
	
	public static List<Contact> contactList = new ArrayList<Contact>();
	
	public void addContact(String firstName, String lastName,
			String phoneNumber, String address) {
		
		String contactID = generateContactID();
		
		Contact newContact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		contactList.add(newContact);
	}
	
	public void deleteContact(String contactID) {
		for(int i = 0; i < ContactService.contactList.size(); i++) {
			if(ContactService.contactList.get(i).getContactID().equals(contactID)) {
				contactList.remove(i);
			}
		}
	}
	
	public String generateContactID(){
		int listLength = ContactService.contactList.size();		
		String contactID = String.valueOf(listLength);		
		return contactID;
	}
	
}
