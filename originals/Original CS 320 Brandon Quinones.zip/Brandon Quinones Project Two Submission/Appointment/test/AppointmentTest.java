/**
 * 
 */
package test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import appointment.AppointmentService;

/**
 * 
 */
public class AppointmentTest {

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		
		AppointmentService testAppointment = new AppointmentService();

		String firstAppointmentID = testAppointment.generateAppointmentID();
		Date firstAppointmentDate = new Date();
		String firstDescription = "This is the first appointment!";
				
		testAppointment.addAppointment(firstAppointmentID, firstAppointmentDate, firstDescription);	
	
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		
		AppointmentService.appointmentList.clear();		

	}

	/**
	 * Test method for {@link appointment.Appointment#Appointment(java.lang.String, java.util.Date, java.lang.String)}.
	 */
	@Test
	public void testAppointment() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link appointment.Appointment#getAppointmentID()}.
	 */
	@Test
	public void testGetAppointmentID() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link appointment.Appointment#getAppointmentDate()}.
	 */
	@Test
	public void testGetAppointmentDate() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link appointment.Appointment#getDescription()}.
	 */
	@Test
	public void testGetDescription() {
		fail("Not yet implemented");
	}

}
