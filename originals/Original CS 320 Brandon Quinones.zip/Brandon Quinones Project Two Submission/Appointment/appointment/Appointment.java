package appointment;

import java.util.Date;

public class Appointment {
	
	String appointmentID; // Convert to 128 bit UUID form
	Date appointmentDate;
	String description;

	// String firstName
	// String lastName
	// boolean hasInsurance
	// String prefferedPhysician -> allowed to be null
	
	//constructor method - with validation of the attributes used
	public Appointment(String appointmentID, Date appointmentDate, String description) {
		if (validateAppointmentID(appointmentID) == true)
			this.appointmentID = appointmentID;
		if (validateDate(appointmentDate) == true)
			this.appointmentDate = appointmentDate;
		if(validateDescription(description) == true)
			this.description = description;
	}
	
	//validate length is 10 and not null 
	private final boolean validateAppointmentID(String appointmentID) {
		// validating that the ID is no longer than 10 characters and is not null 
		if (appointmentID.length() != 10 || appointmentID.isBlank())
			return false;
		else
			return true;
	}
	
	//validate date is not before current date (not in the past)
	private final boolean validateDate(Date appointmentDate) {
		// getting current date
        Date currentDate = new Date(); 
        // validating that date given is not before current date
		if (appointmentDate.before(currentDate) == true)
			return false;
		else
			return true;
	}
	
	//validate length is less than 50 and not null
	private final boolean validateDescription(String description) {
		// validating description is no longer than 50 characters and not null
		if (description.length() > 50 || description.isBlank())
			return false;
		else
			return true;
	}

	
	//getter methods
	public String getAppointmentID() {
		return appointmentID;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public String getDescription() {
		return description;
	}
}
