package appointment;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;


public class AppointmentService {

	//Initializing list for appointment 
	public static List<Appointment> appointmentList = new ArrayList <Appointment>();

	//adding new appointment with passed attributes
	public void addAppointment(String appointmentID, Date appointmentDate, String description) {
		Appointment newAppointment = new Appointment(appointmentID, appointmentDate,description);
		appointmentList.add(newAppointment);
	}
	
	//deleting appointment based on appointmentID
	public void deleteAppointment(String appointmentID) {
		for(int i = 0; i < AppointmentService.appointmentList.size(); i++) {
			if(AppointmentService.appointmentList.get(i).getAppointmentID().equals(appointmentID))
				appointmentList.remove(i);
		}
	}
	
	//randomly generate 10 digit id
	public String generateAppointmentID() throws IllegalArgumentException{
		Random rd = new Random();
		String appointmentID = String.valueOf(rd.nextInt(1000000000, 2147483000));
		for(int i = 0; i < AppointmentService.appointmentList.size(); i++) {
			if(appointmentList.get(i).getAppointmentID().equals(appointmentID))
				return generateAppointmentID();
		}
		return appointmentID;
	}
}
