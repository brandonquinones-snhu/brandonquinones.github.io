package test;

import static org.junit.Assert.*;

import org.junit.Test;

import task.Task;

public class TaskTest {

	@Test
	public void getTaskId() {
		//testing getTaskId method
		int taskId = 1234567890;
		String taskName = "task name";
		String taskDescription = "task description";
		
		Task task = new Task(taskId, taskName, taskDescription);
		int getTaskId = task.getTaskId();

		assertEquals(taskId, getTaskId);	
	}

	@Test
	public void getTaskName() {
		//testing getTaskName method
		int taskId = 1234567890;
		String taskName = "task name";
		String taskDescription = "task description";
		
		Task task = new Task(taskId, taskName, taskDescription);
		String getTaskName = task.getTaskName();

		assertEquals(taskName, getTaskName);	
	}

	@Test
	public void getTaskDescription() {
		//testing getTaskDescription method
		int taskId = 1234567890;
		String taskName = "task name";
		String taskDescription = "task description";
		
		Task task = new Task(taskId, taskName, taskDescription);
		String getTaskDescription = task.getTaskDescription();

		assertEquals(taskDescription, getTaskDescription);	
	}
	
	@Test
	public void setTaskName() {
		//testing setTaskName method
		int taskId = 1234567890;
		String taskName = "task name";
		String taskDescription = "task description";
		
		Task task = new Task(taskId, taskName, taskDescription);
		String getTaskName = task.getTaskName();

		assertEquals(taskName, getTaskName);
		
		String setTaskName = "new task name";
		task.setTaskName(setTaskName);	
		getTaskName = task.getTaskName();

		
		assertEquals(setTaskName, getTaskName);	
	}

	@Test
	public void setTaskDescription() {
		//testing setTaskDescription method
		int taskId = 1234567890;
		String taskName = "task name";
		String taskDescription = "task description";
		
		Task task = new Task(taskId, taskName, taskDescription);
		String getTaskDescription = task.getTaskDescription();

		assertEquals(taskDescription, getTaskDescription);	
		
		String setTaskDescription = "new task description";
		task.setTaskDescription(setTaskDescription);
		getTaskDescription = task.getTaskDescription();
		
		assertEquals(setTaskDescription, getTaskDescription);	
	}
}
