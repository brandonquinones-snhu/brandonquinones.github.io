package test;

import static org.junit.Assert.*;

import org.junit.Test;

import contact.Contact;

public class ContactTest {

	@Test
	public void contactID() {
		String contactID = "123";
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		Contact contact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		String getContactID = contact.getContactID();
		
		assertEquals(contactID, getContactID);	
		
		//negative test case for requirements - over 10
		boolean thrown = false;
		try {
			String badContactID = "123456789000";
			Contact badContact = new Contact(badContactID, firstName, lastName, phoneNumber, address);
		}
		catch (IllegalArgumentException e){
			thrown = true;
		}
		assertTrue(thrown);
		
		//negative test case - blank or null
		thrown = false;
		try {
			String nullContactID = "";
			Contact nullContact = new Contact(nullContactID, firstName, lastName, phoneNumber, address);
		}
		catch (IllegalArgumentException e){	
			thrown = true;
		}
		assertTrue(thrown);
		thrown = false;
		try {
			String nullContactID = null;
			Contact nullContact = new Contact(nullContactID, firstName, lastName, phoneNumber, address);
		}
		catch (NullPointerException e){	
			thrown = true;
		}
		assertTrue(thrown);
	}

	@Test
	public void firstName() {
		String contactID = "123";
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		Contact contact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		String getFirstName = contact.getFirstName();
		
		assertEquals(firstName, getFirstName);	
		
		//negative test case - over 10
		boolean thrown = false;
		try {
			String badFirstName = "VeryLongFirstName";
			Contact badContact = new Contact(contactID, badFirstName, lastName, phoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		
		//negative test case - blank or null
		thrown = false;
		try {
			String nullFirstName = "";
			Contact nullContact = new Contact(contactID, nullFirstName, lastName, phoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		thrown = false;
		try {
			String nullFirstName = null;
			Contact nullContact = new Contact(contactID, nullFirstName, lastName, phoneNumber, address);
			}
		catch (NullPointerException e){
			thrown = true;
			}
		assertTrue(thrown);

	}

	@Test
	public void lastName() {
		String contactID = "123";
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		Contact contact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		String getLastName = contact.getLastName();
		
		assertEquals(lastName, getLastName);	
		
		//negative test case - over 10
		boolean thrown = false;
		try {
			String badLastName = "VeryLongLastName";
			Contact badContact = new Contact(contactID, firstName, badLastName, phoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);

		//negative test case - blank or null
		thrown = false;
		try {
			String nullLastName = "";
			Contact nullContact = new Contact(contactID, firstName, nullLastName, phoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		thrown = false;
		try {
			String nullLastName = null;
			Contact nullContact = new Contact(contactID, firstName, nullLastName, phoneNumber, address);
			}
		catch (NullPointerException e){
			thrown = true;
			}
		assertTrue(thrown);
	}

	@Test
	public void phoneNumber() {
		String contactID = "123";
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		Contact contact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		String getPhoneNumber = contact.getPhoneNumber();
		
		assertEquals(phoneNumber, getPhoneNumber);	
		
		//negative test case - over 10
		boolean thrown = false;
		try {
			String badPhoneNumber = "45156156132324498";
			Contact badContact = new Contact(contactID, firstName, lastName, badPhoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		
		//negative test case - blank or null
		thrown = false;
		try {
			String nullPhoneNumber = "";
			Contact nullContact = new Contact(contactID, firstName, lastName, nullPhoneNumber, address);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		thrown = false;
		try {
			String nullPhoneNumber = null;
			Contact nullContact = new Contact(contactID, firstName, lastName, nullPhoneNumber, address);
			}
		catch (NullPointerException e){
			thrown = true;
			}
		assertTrue(thrown);
	}

	@Test
	public void address() {
		String contactID = "123";
		String firstName = "first";
		String lastName = "last name";
		String phoneNumber = "1234567890";
		String address = "132 SNHU Rd.";
		
		Contact contact = new Contact(contactID, firstName, lastName, phoneNumber, address);
		String getAddress = contact.getAddress();
		
		assertEquals(address, getAddress);	
		
		//negative test case - over 10
		boolean thrown = false;
		try {
			String badAddress = "VeryLongAddressThatIsExcessivleyLongAndIMeanExcessiveLikeTheKindThatMakesYouGoWow";
			Contact badContact = new Contact(contactID, firstName, lastName, phoneNumber, badAddress);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		
		//negative test case - blank or null
		thrown = false;
		try {
			String nullAddress = "";
			Contact nullContact = new Contact(contactID, firstName, lastName, phoneNumber, nullAddress);
			}
		catch (IllegalArgumentException e){
			thrown = true;
			}
		assertTrue(thrown);
		thrown = false;
		try { 
			String nullAddress = null;
			Contact nullContact = new Contact(contactID, firstName, lastName, phoneNumber, nullAddress);
			}
		catch (NullPointerException e){
			thrown = true;
			}
		assertTrue(thrown);	}

}
