package com.example.cs360_bquinones

data class Event(val id: Int, val title: String, val date: String, val time: String)
